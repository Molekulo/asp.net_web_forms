﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminProducts : System.Web.UI.Page
{
    private string FileName;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void SubmitButton_Click(object sender, EventArgs e)
    {
        if (CheckImage())
        {
            Product.InsertProduct(ProductNameTextBox.Text, Convert.ToDouble(PriceTextBox.Text), "img/" + FileName);
            Response.Redirect("Products.aspx");
        }
    }

    private bool CheckImage()
    {
        if (ImageUpload.HasFile)
        {
            try
            {
                if (ImageUpload.PostedFile.ContentType == "image/jpeg" || ImageUpload.PostedFile.ContentType == "image/png")
                {
                    FileName = Path.GetFileName(ImageUpload.FileName);
                    ImageUpload.SaveAs(Server.MapPath("~/img/") + FileName);
                    return true;
                }
                else
                {
                    StatusLabel.Text = "Upload status: Only JPEG or PNG files are accepted!";
                    return false;
                }
            }
            catch (Exception ex)
            {
                StatusLabel.Text = "Upload status: The file could not be uploaded. The following error occured: " + ex.Message;
                return false;
            }
        }
        else
        {
            StatusLabel.Text = "Upload status: You must choose picture for product!";
            return false;
        }
    }
}