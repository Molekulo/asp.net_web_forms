﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// Summary description for Product
/// </summary>
public class Product
{
    public Product()
    {

    }

    public static void InsertProduct(string productName, double price, string imageUrl)
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = WebConfigurationManager.ConnectionStrings["Products"].ConnectionString;

        try
        {
            using (conn)
            {

                conn.Open();

                SqlCommand command = new SqlCommand("INSERT INTO Product(product_name, price, image_url, is_deleted) VALUES(@ProductName, @Price, @ImageUrl, 0);", conn);

                SqlParameter productNameParam = new SqlParameter("@ProductName", SqlDbType.NVarChar);
                productNameParam.Value = productName;

                SqlParameter priceParam = new SqlParameter("@Price", SqlDbType.Money);
                priceParam.Value = price;

                SqlParameter imageUrlParam = new SqlParameter("@ImageUrl", SqlDbType.NVarChar);
                imageUrlParam.Value = imageUrl;

                command.Parameters.Add(productNameParam);
                command.Parameters.Add(priceParam);
                command.Parameters.Add(imageUrlParam);

                int added = command.ExecuteNonQuery();
            }
        }
        catch (Exception err)
        {
            // Handle an error by displaying the information.
        }
    }
}